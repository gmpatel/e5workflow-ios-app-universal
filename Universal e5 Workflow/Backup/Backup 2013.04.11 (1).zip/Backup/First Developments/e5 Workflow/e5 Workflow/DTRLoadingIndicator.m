//
//  DTRLoadingIndicator.m
//  e5 Workflow
//
//  Created by Gunjan Patel on 26/03/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRLoadingIndicator.h"
#import <QuartzCore/QuartzCore.h>

@implementation DTRLoadingIndicator

@synthesize labelMessage, activityIndicator;

- (id)init {
    if (self = [super initWithFrame:CGRectMake(25, 130, 270, 100)]) {
        
        // Vue
        self.backgroundColor = [UIColor blackColor];
        self.alpha = 0.80;
        self.layer.cornerRadius = 5;
        
        // Label : message
        UILabel *theLabelMessage = [[UILabel alloc] initWithFrame:CGRectMake(15, 65, 240, 20)];
        theLabelMessage.backgroundColor = [UIColor clearColor];
        theLabelMessage.textColor = [UIColor whiteColor];
        theLabelMessage.text = NSLocalizedString(@"Loading", @"Loading");
        theLabelMessage.textAlignment = UITextAlignmentCenter;
        theLabelMessage.font = [UIFont boldSystemFontOfSize:16];
        theLabelMessage.adjustsFontSizeToFitWidth = YES;
        
        self.labelMessage = theLabelMessage;
        [self addSubview:theLabelMessage];
        //[theLabelMessage release];
        
        // Activity Indicator
        UIActivityIndicatorView *theActivityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        theActivityIndicator.frame = CGRectMake(115, 15, 40, 40);
        
        self.activityIndicator = theActivityIndicator;
        [self addSubview:theActivityIndicator];
        //[theActivityIndicator release];
        
    }
    return self;
}

- (void)show:(NSString *)theMessage {
    
    self.labelMessage.text = theMessage;
    [self.activityIndicator startAnimating];
    self.hidden = NO;
    [self.superview bringSubviewToFront:self];
    [self refreshPosition];
}

- (void)hide {
    [self.activityIndicator stopAnimating];
    self.hidden = YES;
}

- (void)refreshPosition {
    
    self.center = self.superview.center;
}

- (void)dealloc {
    self.labelMessage = nil;
    self.activityIndicator = nil;
    
    //[super dealloc];
}

@end