//
//  DTRView.m
//  e5 Workflow
//
//  Created by Gunjan Patel on 26/03/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRView.h"

@implementation DTRView

@synthesize loadingIndicator;


- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        
        // Loading Indicator
        DTRLoadingIndicator *theLoadingIndicator = [[DTRLoadingIndicator alloc] init];
        theLoadingIndicator.hidden = YES;   // Hidden by default
        
        self.loadingIndicator = theLoadingIndicator;
        [self addSubview:theLoadingIndicator];
        //[theLoadingIndicator release];
        
        
    }
    return self;
}

- (void)showLoadingIndicator:(NSString *)theMessage {
    //NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    [self.loadingIndicator performSelectorOnMainThread:@selector(show:) withObject:theMessage waitUntilDone:NO];
    
    //[pool release];
}

- (void)hideLoadingIndicator {
    //NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    [self.loadingIndicator performSelectorOnMainThread:@selector(hide) withObject:nil waitUntilDone:NO];
    
    //[pool release];
}

- (void)dealloc {
    self.loadingIndicator = nil;
    
    //[super dealloc];
}


@end