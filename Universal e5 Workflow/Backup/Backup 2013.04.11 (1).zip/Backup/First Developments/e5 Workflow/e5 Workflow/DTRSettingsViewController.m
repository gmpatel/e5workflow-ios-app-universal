//
//  DTRSettingsViewController.m
//  e5
//
//  Created by Gunjan Patel on 26/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRSettingsViewController.h"

@implementation DTRSettingsViewController


@synthesize myTab1URL;
@synthesize myTab1User;
@synthesize myTab1Password;
@synthesize myTab2URL;
@synthesize myTab2User;
@synthesize myTab2Password;
@synthesize myTab3URL;
@synthesize myTab3User;
@synthesize myTab3Password;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    // Do any additional setup after loading the view.
    
    //[myScrollView setScrollEnabled:YES];
    //[myScrollView setContentSize:CGSizeMake(320, 2000)];
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *data;
    
    data = [defaults objectForKey:@"Tab1URL"];
    self.myTab1URL.text = data;
    
    data = [defaults objectForKey:@"Tab1User"];
    self.myTab1User.text = data;
    
    data = [defaults objectForKey:@"Tab1Password"];
    self.myTab1Password.text = data;
    
    
    data = [defaults objectForKey:@"Tab2URL"];
    self.myTab2URL.text = data;
    
    data = [defaults objectForKey:@"Tab2User"];
    self.myTab2User.text = data;
    
    data = [defaults objectForKey:@"Tab2Password"];
    self.myTab2Password.text = data;
    
    
    data = [defaults objectForKey:@"Tab3URL"];
    self.myTab3URL.text = data;
    
    data = [defaults objectForKey:@"Tab3User"];
    self.myTab3User.text = data;
    
    data = [defaults objectForKey:@"Tab3Password"];
    self.myTab3Password.text = data;
    
    
    [super viewDidLoad];
}

- (IBAction)myTextFields_DidEndOrExit:(id)sender {
    [sender resignFirstResponder];
    
}

- (IBAction)myTextFields_EditingDidBegin:(id)sender {
    UITextField *field = (UITextField *) sender;
    
    [self animateTextField:field up:YES];
}





- (IBAction)myTextFields_EditingDidEnd:(id)sender {
    UITextField *field = (UITextField *) sender;
    
    [self animateTextField:field up:NO];
    
    NSString *data = field.text;
    int key = field.tag;
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    
    switch (key) {
        case 11:
            [defaults setObject:data forKey:@"Tab1URL"];
            break;
            
        case 12:
            [defaults setObject:data forKey:@"Tab1User"];
            break;
            
        case 13:
            [defaults setObject:data forKey:@"Tab1Password"];
            break;
            
        case 21:
            [defaults setObject:data forKey:@"Tab2URL"];
            break;
            
        case 22:
            [defaults setObject:data forKey:@"Tab2User"];
            break;
            
        case 23:
            [defaults setObject:data forKey:@"Tab2Password"];
            break;
            
        case 31:
            [defaults setObject:data forKey:@"Tab3URL"];
            break;
            
        case 32:
            [defaults setObject:data forKey:@"Tab3User"];
            break;
            
        case 33:
            [defaults setObject:data forKey:@"Tab3Password"];
            break;
            
        default:
            break;
    }
    
    [defaults synchronize];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    const int movementDistance = -180; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}




@end
