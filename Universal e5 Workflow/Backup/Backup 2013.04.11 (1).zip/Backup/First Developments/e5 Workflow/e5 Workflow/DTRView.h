//
//  DTRView.h
//  e5 Workflow
//
//  Created by Gunjan Patel on 26/03/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UIKit/UIKit.h>
#import "DTRLoadingIndicator.h"

@interface DTRView : UIView {
    
    DTRLoadingIndicator *loadingIndicator;
    
}

@property(retain) DTRLoadingIndicator *loadingIndicator;

- (void)showLoadingIndicator:(NSString *)theMessage;
- (void)hideLoadingIndicator;

@end