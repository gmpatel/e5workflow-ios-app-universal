//
//  DTRGlobal.h
//  e5
//
//  Created by Gunjan Patel on 27/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

@interface DTRGlobal : NSObject 

extern int currentTab;

- (void)loadURL :(NSString *)url :(NSString *)user :(NSString *)password;

@end
