//
//  DTRSettingsViewController.h
//  e5
//
//  Created by Gunjan Patel on 26/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DTRSettingsViewController : UIViewController {
    IBOutlet UIScrollView *scrollView;
}

@property (strong, nonatomic) IBOutlet UITextField *myTab1URL;
@property (strong, nonatomic) IBOutlet UITextField *myTab1User;
@property (strong, nonatomic) IBOutlet UITextField *myTab1Password;

@property (strong, nonatomic) IBOutlet UITextField *myTab2URL;
@property (strong, nonatomic) IBOutlet UITextField *myTab2User;
@property (strong, nonatomic) IBOutlet UITextField *myTab2Password;

@property (strong, nonatomic) IBOutlet UITextField *myTab3URL;
@property (strong, nonatomic) IBOutlet UITextField *myTab3User;
@property (strong, nonatomic) IBOutlet UITextField *myTab3Password;

@end