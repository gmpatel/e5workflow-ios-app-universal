//
//  DTRViewController.m
//  WebViewTest
//
//  Created by Gunjan Patel on 28/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRViewController.h"

@interface DTRViewController ()

@end

@implementation DTRViewController

@synthesize myRefreshButton;
@synthesize myWebView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)myRefreshButton_Clicked:(id)sender {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSInteger counter = [defaults integerForKey:@"Counter"];
    counter++;
    [defaults setInteger:counter forKey:@"Counter"];
    
    if(counter%2 == 0)
    {
        _authed = YES;
        _URL = @"http://www.google.com";
        _User = @"";
        _Password = @"";
    }
    else
    {
        _authed = NO;
        _URL = @"http://intranet.dataract.com.au";
        _User = @"Dataract2\\Gunjan";
        _Password = @"gmcm7880";
    }
    
    [self loadUrl];
}

- (void)loadUrl {
    [self.myWebView stopLoading];
    [self.myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_URL]]];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
{
    if (!_authed) {
        [[NSURLConnection alloc] initWithRequest:request delegate:self];
        NSLog(@"Did start loading: %@ auth:%d", [[request URL] absoluteString], _authed);
        return NO;
    }
    else {
        NSLog(@"Did start loading: %@ auth:%d", [[request URL] absoluteString], _authed);
        return YES;
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge;
{
    NSLog(@"Got Auth Challange, Fail Count : %d", [challenge previousFailureCount]);
    
    if ([challenge previousFailureCount] == 0) {
        _authed = YES;
        [[challenge sender] useCredential:[NSURLCredential credentialWithUser:_User password:_Password persistence:NSURLCredentialPersistencePermanent] forAuthenticationChallenge:challenge];
    } else {
        _authed = YES;
        [[challenge sender] cancelAuthenticationChallenge:challenge];
        
        NSURL *url = [NSURL URLWithString:@"about:blank"];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.myWebView loadRequest:request];
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Login Failed !!" message:@"Please check your credentials." delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [alert show];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;
{
    NSLog(@"received response via nsurlconnection");
    [self.myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_URL]]];
}

- (BOOL)connectionShouldUseCredentialStorage:(NSURLConnection *)connection;
{
    return NO;
}

@end
