//
//  DTRAppDelegate.h
//  e5
//
//  Created by Gunjan Patel on 26/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DTRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
