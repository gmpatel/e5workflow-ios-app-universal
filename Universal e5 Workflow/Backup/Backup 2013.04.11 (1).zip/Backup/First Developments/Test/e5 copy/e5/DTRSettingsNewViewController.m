//
//  DTRSettingsNewViewController.m
//  e5
//
//  Created by Gunjan Patel on 28/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRSettingsNewViewController.h"
#import "DTRGlobal.h"

@interface DTRSettingsNewViewController ()

@end

@implementation DTRSettingsNewViewController

@synthesize myCancelButton;
@synthesize mySaveButton;

@synthesize myTextTitle;
@synthesize myTextURL;
@synthesize myTextUser;
@synthesize myTextPassword;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [self loadSettings];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dismissKeyboard {
    [myTextTitle resignFirstResponder];
    [myTextURL resignFirstResponder];
    [myTextUser resignFirstResponder];
    [myTextPassword resignFirstResponder];
}

- (IBAction)mySaveButton_TouchDown:(id)sender {
    [self saveSettings];
    [self dismissViewControllerAnimated:YES completion:nil]; //[self dismissModalViewControllerAnimated:YES];
}

- (IBAction)myCancelButton_TouchDown:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil]; //[self dismissModalViewControllerAnimated:YES];
}
- (IBAction)myTextFields_EditingDidBegin:(id)sender {
    //UITextField *field = (UITextField *) sender;
    //[self animateTextField:field up:YES];
}
- (IBAction)myTextFields_EditingDidEnd:(id)sender {
    //UITextField *field = (UITextField *) sender;
    //[self animateTextField:field up:NO];
}
- (IBAction)myTextFields_TouchUpOutSide:(id)sender {
    //UITextField *field = (UITextField *) sender;
    //[sender resignFirstResponder];
}
- (IBAction)myTextFields_DidEndOrExit:(id)sender {
    [sender resignFirstResponder];
}

- (void)loadSettings {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSInteger currentTab = [defaults integerForKey:@"CurrentTab"];
    
    NSString *data;
    
    NSString *keyTitle = [NSString stringWithFormat: @"Tab%dTitle", currentTab];
    NSString *keyURL = [NSString stringWithFormat: @"Tab%dURL", currentTab];
    NSString *keyUser = [NSString stringWithFormat: @"Tab%dUser", currentTab];
    NSString *keyPassword = [NSString stringWithFormat: @"Tab%dPassword", currentTab];
    
    data = [defaults objectForKey:keyTitle];
    self.myTextTitle.text = data;
    
    data = [defaults objectForKey:keyURL];
    self.myTextURL.text = data;
    
    data = [defaults objectForKey:keyUser];
    self.myTextUser.text = data;
    
    data = [defaults objectForKey:keyPassword];
    self.myTextPassword.text = data;
}

- (void)saveSettings {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSInteger currentTab = [defaults integerForKey:@"CurrentTab"];
    
    NSString *data;
    
    NSString *keyTitle = [NSString stringWithFormat: @"Tab%dTitle", currentTab];
    NSString *keyURL = [NSString stringWithFormat: @"Tab%dURL", currentTab];
    NSString *keyUser = [NSString stringWithFormat: @"Tab%dUser", currentTab];
    NSString *keyPassword = [NSString stringWithFormat: @"Tab%dPassword", currentTab];
    
    data = self.myTextTitle.text;
    [defaults setObject:data forKey:keyTitle];
    
    data = self.myTextURL.text;
    [defaults setObject:data forKey:keyURL];
    
    data = self.myTextUser.text;
    [defaults setObject:data forKey:keyUser];
    
    data = self.myTextPassword.text;
    [defaults setObject:data forKey:keyPassword];
}

@end
