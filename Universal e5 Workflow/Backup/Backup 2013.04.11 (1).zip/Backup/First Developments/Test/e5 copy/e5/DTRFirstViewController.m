//
//  DTRFirstViewController.m
//  e5
//
//  Created by Gunjan Patel on 26/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRFirstViewController.h"

@interface DTRFirstViewController ()

@end

@implementation DTRFirstViewController

@synthesize myRefresh;
@synthesize myNavigationBar;
@synthesize myWebView;
@synthesize myNavigationTitle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [self loadURL];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults setInteger:1 forKey:@"CurrentTab"];
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)myRefreshClicked:(id)sender {
  /*  NSString *user = @"dataract2\\gunjan";
    NSString *pass = @"gmcm7880";
    
    NSURLCredential *credential = [NSURLCredential credentialWithUser:user password:pass persistence:NSURLCredentialPersistenceForSession];
    
   NSURLProtectionSpace *protectionSpace = [[NSURLProtectionSpace alloc]
                                             initWithHost:@"myhost"
                                             port:80
                                             protocol:@"http"
                                             realm:@"myhost" // check your web site settigns or log messages of didReceiveAuthenticationChallenge
                                             authenticationMethod:NSURLAuthenticationMethodDefault];
    
    
    [[NSURLCredentialStorage sharedCredentialStorage] setDefaultCredential:credential forProtectionSpace:protectionSpace];
    [protectionSpace 
    
    NSURL *url = [NSURL URLWithString:@"http://intranet.dataract.com.au"]];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.myWebView loadRequest:request];
   */
    
    [self loadURL];
}

- (void)loadURL {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *Title = [defaults objectForKey:@"Tab1Title"];
    NSString *URL = [defaults objectForKey:@"Tab1URL"];
    NSString *User = [defaults objectForKey:@"Tab1User"];
    NSString *Password = [defaults objectForKey:@"Tab1Password"];
    
    NSURL *url = [NSURL URLWithString:URL]; //@"http://www.google.com"
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    if(Title.length == 0) {
        self.myNavigationTitle.title = @"Scene 1";
        
    }
    else {
        self.myNavigationTitle.title = Title;
        
    }
    
    [self.myWebView loadRequest:request];
}

@end
