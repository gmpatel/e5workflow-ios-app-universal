//
//  DTRThirdViewController.h
//  e5
//
//  Created by Gunjan Patel on 26/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DTRThirdViewController : UIViewController

@property (strong, nonatomic) IBOutlet UINavigationBar *myNavigationBar;

@property (strong, nonatomic) IBOutlet UINavigationItem *myNavigationTitle;

@property (strong, nonatomic) IBOutlet UIWebView *myWebView;

@property (strong, nonatomic) IBOutlet UIBarButtonItem *myRefresh;

- (IBAction)myRefreshClicked:(id)sender;

- (void)loadURL;

@end
