//
//  DTRThirdViewController.m
//  e5
//
//  Created by Gunjan Patel on 26/02/13.
//  Copyright (c) 2013 Dataract Pty Ltd. All rights reserved.
//

#import "DTRThirdViewController.h"

@interface DTRThirdViewController ()

@end

@implementation DTRThirdViewController

@synthesize myRefresh;
@synthesize myNavigationBar;
@synthesize myWebView;
@synthesize myNavigationTitle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}
- (IBAction)myRefreshClicked:(id)sender {
    [self loadURL];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [self loadURL];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults setInteger:3 forKey:@"CurrentTab"];
    [super viewDidAppear:animated];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loadURL {
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *Title = [defaults objectForKey:@"Tab3Title"];
    NSString *URL = [defaults objectForKey:@"Tab3URL"];
    NSString *User = [defaults objectForKey:@"Tab3User"];
    NSString *Password = [defaults objectForKey:@"Tab3Password"];
    
    NSURL *url = [NSURL URLWithString:URL]; //@"http://www.google.com"
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    if(Title.length == 0) {
        self.myNavigationTitle.title = @"Scene 3";
        
    }
    else {
        self.myNavigationTitle.title = Title;
        
    }
    
    [self.myWebView loadRequest:request];
}

@end
